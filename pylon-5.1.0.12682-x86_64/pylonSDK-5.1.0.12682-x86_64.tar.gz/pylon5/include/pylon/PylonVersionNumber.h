// This file has been generated automatically using:
// "/home/builder/jenkins_root/workspace/PylonLinux_ReleaseBuild/Build/FileTemplates/PylonVersionNumber.template.h"
// DO NOT EDIT!

#define PYLON_VERSION_MAJOR           5
#define PYLON_VERSION_MINOR           1
#define PYLON_VERSION_SUBMINOR        0
#define PYLON_VERSION_BUILD           12682
#define PYLON_VERSIONSTRING_MAJOR     "5"
#define PYLON_VERSIONSTRING_MINOR     "1"
#define PYLON_VERSIONSTRING_SUBMINOR  "0"
#define PYLON_VERSIONSTRING_BUILD     "12682"
#define PYLON_VERSIONSTRING_EXTENSION ""
